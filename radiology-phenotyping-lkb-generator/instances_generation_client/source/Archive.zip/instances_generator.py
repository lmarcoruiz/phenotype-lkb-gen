'''
Created on 25 ene 2023

@author: luis
'''
# import requests module
import requests
from requests.auth import HTTPBasicAuth
import os
from pathlib import Path
import codecs
import json


class EhrCreationError(Exception):
    pass
class TemplateCreationError(Exception):
    pass
class ExampleCompositionCreationError(Exception):
    pass
class CompositionStorageError(Exception):
    pass

def generateSampleInstanceAndReturnUID(template_id, ehrId):
    # Making a get request to generate a sample instance
    url_to_generate_compo = 'https://rest.ehrscape.com/rest/v1/template/'+template_id+'/example?format=FLAT'
    
    try:
        response = requests.get(url_to_generate_compo,
                    auth = HTTPBasicAuth('luismarcoruiz', 'luis2ruiz'))
    except Exception as e:
        print(e)
        raise ExampleCompositionCreationError(f'An error occurred when creating example instance from template {template_id} and EHR id {ehrId}')

          
    # print request object
    dataToPost = response.json()
    
    return dataToPost


def save_instance_in_flat_format(data_to_post, ehr_id, template_id):
    #now store in flat format, get its uid and  retrieve in XML
    paramss = {'templateId' : template_id, 'ehrId':ehr_id}
   # try:
    url_to_post_compo = 'https://rest.ehrscape.com/rest/v1/composition'
    print("The problematic EHR id is: ", ehr_id)
    response = requests.post(url=url_to_post_compo, json=data_to_post, 
    auth = HTTPBasicAuth('luismarcoruiz', 'luis2ruiz'), headers={'Content-Type': 'application/json','Accept': 'application/json'}, params=paramss)
   # except Exception as e:
    #    print(e)
     #   raise CompositionStorageError(f'An error occurred when creating example instance from template {template_id} and EHR id {ehr_id}')

    print(response.content)
    request_get_compo = response.json()
    compositionUid = request_get_compo["compositionUid"]
    return compositionUid

def get_composition_in_non_flat_format(ehr_id, compositionUid):
      #get the composition in JSON (not FLAT) or XML
    url_get_existing_compo = "https://rest.ehrscape.com/rest/openehr/v1/ehr/"+ehr_id+"/composition/"+compositionUid
    full_compo_json = requests.get(url_get_existing_compo,
                auth = HTTPBasicAuth('luismarcoruiz', 'luis2ruiz'))
    return Composition_instance_wrapper(compositionUid, full_compo_json.json())
  

class Composition_instance_wrapper:
    def __init__(self, openehr_uid, composition_body):
        self.openehr_uid = openehr_uid
        self.composition_body = composition_body
    
def upload_template(template_name: str):
    #f = open(template_file_name, "r")
    #print(f.read())
    #invocar la creacion de la template en el openehr repo
    try:
        url_upload_template = "https://rest.ehrscape.com/rest/v1/template/"
        paramss = {'templateId' : template_name}
        response = ""
        template_file_name = "../resources/"+template_name+".opt"
        f = open("../resources/"+template_name+".opt", "r")
        payload = f.read()
        #with open(template_file_name, "r") as payload:
        response = requests.post(url=url_upload_template, data=payload.encode('utf-8'), 
                auth = HTTPBasicAuth('luismarcoruiz', 'luis2ruiz'), headers={'Content-Type': 'application/xml','Accept': 'application/xml'}, params=paramss)
            #print(payload.encode())
    except Exception as e:
        print(e)
        raise TemplateCreationError(f'An error occurred when creating the template with id {template_name}')
    finally:
        f.close()
        
    return response

def create_new_ehr():
    try:
        url_to_generate_compo = 'https://rest.ehrscape.com/rest/openehr/v1/ehr'
        response = requests.post(url_to_generate_compo,
                    auth = HTTPBasicAuth('luismarcoruiz', 'luis2ruiz'), headers={'Content-Type': 'application/json','Accept': 'application/json'})
    except Exception as e:
        print(e)
        raise EhrCreationError(f'An error occurred when creating the new EHR: '+e)

    return response

def generate_instances_for_template(template_id, number_of_instances):
    """Generated the specified number of instances for the provided template for a single newly created EHR"""
    
    dict_new_compos = {}
    for x in range(0, number_of_instances):
        
        #Upload template
        template_name = template_id+".opt"
        response = upload_template(template_id)
        
        #create EHR
        ehr_creation_response = create_new_ehr()
        print("the ehr response is: ", ehr_creation_response.text)
        new_ehrId = str(ehr_creation_response.headers['openEHR-uri']).replace("ehr:/","")
        
        #create instances
        new_instance = generateSampleInstanceAndReturnUID(template_id, new_ehrId)
        
        #save instance in flat format to get it in hierarchical JSON or XML
        compositionId = save_instance_in_flat_format(new_instance, new_ehrId, template_id)
        non_flat_compo = get_composition_in_non_flat_format(new_ehrId, compositionId)
        dict_new_compos[non_flat_compo.openehr_uid]=non_flat_compo
        
        try:
            file_name=template_id + non_flat_compo.openehr_uid+".json"
            file_with_instance =  open(file_name, "w")
            file_with_instance.write(json.dumps(non_flat_compo.composition_body))
        except Exception as e:
            print(e)
            raise EhrCreationError(f'An error occurred when writing new generated composition to a file:'+file_name)
    
    return dict_new_compos

        
def main():
    print("==========Start of execution============!")
    ehrId = '6ef67515-99d6-4d3b-b7d1-84138a52032b'
    template_sample_patient =  "sample_patient"
    templateId_valkyrie_assessment = "Valkyrie_depresion_assessment"

    dic_composition_wrapper = generate_instances_for_template(templateId_valkyrie_assessment, 5) #generateSampleInstanceAndReturnUID(template_sample_patient, ehrId)
    print("The compositions created are: ", dic_composition_wrapper.keys())
    print("==========End of  execution 1============!")


    

if __name__ == "__main__":
    main()
    
    
